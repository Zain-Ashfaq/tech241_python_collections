# Define a list with some cool things inside. E.g. things you would buy if you were a millionaire. The list must have at least 5 elements.

millionaire_wish_list = ["Yacht", "Mansion", "Nissan Skyline r34", "Private jet", "Rolex"]

print(millionaire_wish_list)

print(type(millionaire_wish_list))

print(millionaire_wish_list[0])

print(millionaire_wish_list[1])

print(millionaire_wish_list[-1])

millionaire_wish_list[0] = "Small Country"

millionaire_wish_list[2] = "Vintage sports car"

print(millionaire_wish_list)

millionaire_wish_list.append("Private island")

print(millionaire_wish_list)

millionaire_wish_list.remove("Mansion")

print(millionaire_wish_list)

millionaire_wish_list.pop()

print(millionaire_wish_list)
